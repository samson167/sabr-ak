
  # Personal Profile Website

  This is a code bundle for Personal Profile Website. The original project is available at https://www.figma.com/design/p0TTdqMZ3CXa2VVlF62kNw/Personal-Profile-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  